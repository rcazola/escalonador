
package escalonadorroundrobin;

public class Processo {
    private int numeroProcesso;
	private int numCiclos;
	private int tempoChegada;
	private int tempoEspera;
	private int tempoTermino;
	private int tempoAcabar;
	private int operacao[];

        /**
         * 
         * @return Pega e retorna a operação que a lista vai fazer 
         */
        
	public int[] getOperacao() {
		return operacao;
	}

        /**
         * 
         * @param operacao Vai definir um número de operação 
         */
        
	public void setOperacao(int[] operacao) {
		this.operacao = operacao;
	}

        /**
         * 
         * @return O numero de processos 
         */
        
	public int getNumeroProcesso() {
		return numeroProcesso;
	}

        /**
         * 
         * @param numeroProcesso Define o número de processos
         */
        
	public void setNumeroProcesso(int numeroProcesso) {
		this.numeroProcesso = numeroProcesso;
	}

        /**
         * 
         * @return Pega o número de ciclos que estão sendo feito no Processamento 
         */
        
	public int getNumCiclos() {
		return numCiclos;
	}
/**
 * 
 * @param numCiclos Define o número de ciclos 
 */
	public void setNumCiclos(int numCiclos) {
		this.numCiclos = numCiclos;
	}

        /**
         * 
         * @return Pega o tempo de chegada de cada processo 
         */
        
	public int getTempoChegada() {
		return tempoChegada;
	}
/**
 * 
 * @param tempoChegada Define o tempo de chegada dos processos 
 */
        
	public void setTempoChegada(int tempoChegada) {
		this.tempoChegada = tempoChegada;
	}

        /**
         * 
         * @return Pega o tempo de espera dos processos
         */
        
	public int getTempoEspera() {
		return tempoEspera;
	}

        /**
         * 
         * @param tempoEspera Define o tempo de espera dos processos
         */
        
	public void setTempoEspera(int tempoEspera) {
		this.tempoEspera = tempoEspera;
	}

        /**
         * 
         * @return Pega o tempo de termino de processamento 
         */
        
	public int getTempoTermino() {
		return tempoTermino;
	}

        /**
         * 
         * @param tempoTermino Define o tempo que falta para terminar o processamento 
         */
        
	public void setTempoTermino(int tempoTermino) {
		this.tempoTermino = tempoTermino;
	}

        /**
         * 
         * @return O tempo que falta para acabar a Execução 
         */
        
	public int getTempoAcabar() {
		return tempoAcabar;
	}

        /**
         * 
         * @param tempoAcabar Define em quanto tempo o Processo vai executar 
         */
        
	public void setTempoAcabar(int tempoAcabar) {
		this.tempoAcabar = tempoAcabar;
	}
}
