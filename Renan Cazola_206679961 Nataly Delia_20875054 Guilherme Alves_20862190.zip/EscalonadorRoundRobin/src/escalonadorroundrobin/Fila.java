package escalonadorroundrobin;


public class Fila {
	private Processo processo[];
	private int tamanho;
        
        /**
         * 
         * @param qtdProcessos Quantidade de processos que serão inseridos na fila 
         */

	public Fila(int qtdProcessos) {
		processo = new Processo[qtdProcessos];
		tamanho = 0;
	}

        /**
         * 
         * @return  Retorna o tamanho da fila
         */
        
	public boolean vazia() {
		return tamanho == 0;
	}
/**
 * 
 * @return O tamanho da fila 
 */
	public boolean cheia() {
		return tamanho == processo.length;
	}

        /**
         * 
         * @param num Vai pegar o processo para ser retornado em outro método
         * @return O processo 
         */
	public Processo getProcesso(int num) {
		return processo[num];
	}
/**
 * 
 * @param p Pega o Processo e seta ele como "P"
 * @param posicao Pega a posição do processo e coloca o "p" nela
 */
        
	public void setProcesso(Processo p, int posicao) {
		this.processo[posicao] = p;
	}
/**
 * 
 * @return Apenas retorna o tamanho do Processo 
 */
        
	public int getTamanho() {
		return tamanho;
	}

        /**
         * 
         * @return Apos percorrer a lista o "aux" vai retornar o tamanho dela
         */
        
	public Processo[] pecorrer() {
		Processo aux[] = new Processo[tamanho];
		for (int i = 0; i < tamanho; i++) {
			Processo p = processo[i];
			aux[i] = p;
		}
		return aux;
	}

        /**
         * 
         * @param processo Cria e Adiciona o processo ao final da fila
         */
	public void adicionafinal(Processo processo) {

		if (!cheia()) {
			this.processo[tamanho] = processo;
			tamanho++;
		} else {
			System.out.print("Erro, Lista esta cheia");
		}
	}

       /**
        * 
        * @return Remove o início e retorna a fila e o tamanho dela
        */
        
	public Processo removerinicio() {
		Processo p = new Processo();
		if (vazia()) {
//			System.out.println("fila vazia, nao é possivel remover");
		} else {
			p = this.processo[0];
			for (int i = 0; i < tamanho - 1; i++) {
				this.processo[i] = processo[i + 1];
			}
			tamanho--;

		}
		
		return p;
	}

        
        /**
         * 
         * @param processo Adiciona processo ao inicio da fila 
         */
	public void adicionainicio(Processo processo) {
		if (!cheia()) {
			for (int i = tamanho; i >= 1; i--) {
				this.processo[i] = this.processo[i - 1];
			}
			tamanho++;
			this.processo[0] = processo;
		} else {
			System.out
					.println("lista cheia não possível  adicionar mais elementos");

		}
	}

/**
 * 
 * @param vetor  Insere os valores dentro do vetor e organiza a fila 
 *
 */
        
	public static int[] InsertionSort(int[] vetor) {
		for (int i = 0; i < vetor.length; i++) {

			int a = vetor[i];
			for (int j = i - 1; j >= 0 && vetor[j] > a; j--) {

				vetor[j + 1] = vetor[j];
				vetor[j] = a;
			}
		}
		return vetor;
	}  
}
